# gl-blog
This gl-block plugin is the swiper js based plugin.