<?php
/**
 * Plugin Name:       Gl Blocks
 * Description:       Gl Blocks is a versatile and user-friendly plugin designed to enhance your website with three customizable blocks: Team, Skill, and FAQ Repeater. This plugin is perfect for showcasing your team members, highlighting various skills, and providing an interactive FAQ section. Whether you're managing a corporate site, a personal portfolio, or a blog, Gl Blocks offer an easy and efficient way to enrich your content and engage your audience.
 * Requires at least: 6.1
 * Requires PHP:      7.4
 * Version:           1.0.0
 * Author:            Glthemes
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       gl-blocks
 *
 * @package CreateBlock
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Registers the block using the metadata loaded from the `block.json` file.
 * Behind the scenes, it registers also all assets so they can be enqueued
 * through the block editor in the corresponding context.
 *
 * @see https://developer.wordpress.org/reference/functions/register_block_type/
 */
function gl_blocks_block_init() {

	register_block_type( __DIR__ . '/build/skill' );
	register_block_type( __DIR__ . '/build/faq' );
	register_block_type( __DIR__ . '/build/team',[
		'render_callback' => 'gl_blocks_team_listing'
	] );
}
add_action( 'init', 'gl_blocks_block_init' );

add_filter( 'block_categories_all' , function( $categories ) {

    // Adding a new category.
	$categories[] = array(
		'slug'  => 'gl-blocks-category',
		'title' => __( 'GL Category','gl-blocks' ),
	);

	return $categories;
} );

function gl_blocks_team_listing( $attributes ){
	ob_start();

    $args = array(
        'post_type'   => 'team',
		'post_status' => 'publish',
    );

    if( isset( $attributes['selectedPosts'] ) ){
        $args['post__in'] = $attributes['selectedPosts'];
    }
    $team = new WP_Query( $args );
	if( $team->have_posts() ){ ?>
        <div class="gl__team__wrapper">
            <div class="swiper gl-team-swiper">
                <div class="swiper-wrapper">
                    <?php 
                        if( $team-> have_posts() ){
                            while($team-> have_posts()){
                                $team-> the_post();            
                                $email       = get_post_meta( get_the_ID(), '_law_firm_pro_team_email', true );
                                $contact     = get_post_meta( get_the_ID(), '_law_firm_pro_team_contact', true );
                                $social_link = get_post_meta( get_the_ID(), '_team_social_icons', true );	
                                ?>
                                <div class="swiper-slide">
                                    <div class="team__card">
                                        <div class="team__img">
                                            <?php 
                                                if( has_post_thumbnail() ){  
                                                    the_post_thumbnail( 'thumbnail' );               
                                                }
                                                if( $social_link ){ ?>
                                                    <div class="social-wrap">
                                                        <ul class="social-networks">
                                                            <?php 
                                                                foreach( $social_link as $key => $link ){ 
                                                                    if( $link ){ ?>
                                                                        <li>
                                                                            <a href="<?php echo esc_url( $link );?>" target="_blank" rel="nofollow noopener">
                                                                                <?php echo wp_kses( law_firm_pro_handle_all_svgs( $key ), law_firm_pro_get_kses_extended_ruleset() );?>
                                                                            </a>
                                                                        </li>
                                                                    <?php 
                                                                    }
                                                                }
                                                            ?>
                                                        </ul>
                                                    </div>
                                                <?php
                                                }
                                            ?>
                                        </div>
                                        <div class="team__content">
                                            <?php 
                                                $category_list = get_the_term_list( get_the_ID(), 'team_category', '<span class="team__title">', '', '</span>' );
                                                if( isset( $category_list ) && ! empty( $category_list ) ){
                                                    echo wp_kses_post( $category_list );
                                                }
                                            ?>
                                            <h5 class="team__name">
                                                <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
                                            </h5>
                                            <div class="team__bio">
                                                <?php 
                                                    if( has_excerpt() ){
                                                        echo wp_trim_words( get_the_excerpt(), 15 );
                                                    }else{
                                                        echo wpautop( wp_trim_words( get_the_content(), 15 ) );
                                                    } 
                                                ?>
                                            </div>
                                            <?php if( $email || $contact ){ ?>
                                                <div class="contact-info">
                                                    <?php if( $email ){ ?>
                                                        <div class="info">
                                                            <span class="icon-mail icon"></span>
                                                            <a href="mailto:<?php echo esc_attr( $email ); ?>">
                                                                <?php echo esc_html( $email ); ?>
                                                            </a>
                                                        </div>
                                                    <?php } if( $contact ){ ?>
                                                        <div class="info">
                                                            <span class="icon-phone icon"></span>
                                                            <a href="tel:<?php echo esc_attr( $contact ); ?>">
                                                                <?php echo esc_html( $contact ); ?>
                                                            </a>
                                                        </div>
                                                    <?php } ?>
                                                </div>
                                            <?php } ?>
                                        </div>
                                    </div>
                                </div>
                            <?php   
                            } 
                        } 
                    ?>
                </div>
                <div class="swiper-button-next"></div>
                <div class="swiper-button-prev"></div>
                <div class="swiper-pagination"></div>
            </div>
        </div>
    <?php
    }else{
        echo esc_html__( "No Teams Available",'gl-blocks' );
    }
    $output_string = ob_get_contents();
	ob_end_clean();
	return $output_string;
}